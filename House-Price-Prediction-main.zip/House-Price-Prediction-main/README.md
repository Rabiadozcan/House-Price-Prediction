# House-Price-Prediction
The primary goal of the project is to develop a model capable of predicting the prices of houses based on various features.This dataset of residential homes in Ames, Iowa, contains 79 explanatory variables.
